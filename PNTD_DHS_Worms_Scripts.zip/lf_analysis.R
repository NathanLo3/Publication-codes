##############################
# Project: Deworming in pre-school children Data Validation (Suppl. Script)

# Coded by Ribhav Gupta (Stanford University)
# Email: ribhav.gupta97@gmail.com
# Last updated: 06/20/19 
``
#Purpose of File: Analysis of deworming coverage by level of LF endemicity

# Files Required:
#   1. Files from WHO on LF Coverage on 2015
#   2. Generated file on deworming (STH) coverage reported to WHO used in main analysis

# **Note: Directory should be updated based on where files are saved.**

#File Outputs:
# 1. 
# 2. 

setwd("/Users/rgupta97/Documents/Lab_Work")
library(readxl)
library(lubridate)
library(ggplot2)
library(extrafont)

country <- "Myanmar"

if(country == "Philippines"){
  lf_frame <- read_excel("PreSAC_PH_IN.xlsx", sheet = "PHILIPPINES")
  sth_frame <- read_excel("Philippines_070719_Coverage_Demographics.xlsx", sheet = "Deworming Coverage")
}
if(country == "Myanmar"){
  lf_frame <- read_excel("MM_LF_2015.xlsx")
  sth_frame <- read_excel("Myanmar_070719_Coverage_Demographics.xlsx", sheet = "Deworming Coverage")
}


#WHO - DHS
cov_difference <- c()
districts <- unique(sth_frame$region)
for(i in 1:length(districts)){
  WHO_estimation <- sth_frame$value[which(sth_frame$region == districts[i] & sth_frame$source == "WHO estimation")]
  DHS_estimation <- sth_frame$value[which(sth_frame$region == districts[i] & sth_frame$source == "DHS estimation")]
  cov_difference[i] <- WHO_estimation - DHS_estimation
}

LFendemicCovFrame <- data.frame(districts,cov_difference)


if(country == "Philippines"){
  endemic_districts_ifAny <- c("western visayas","zamboanga peninsula","northern mindanao","soccsksargen","bangsamoro","caraga")
  endemic_districts_half <- c()
  endemic_districts_all <- c()
}
if(country == "Myanmar"){
  #Endemic District Categorization Options
  endemic_districts_ifAny <- c("kachin","kayin","bago","magway","mandalay","sagaing","taninthayi","rakhine","mon","yangon","ayeyarwaddy","chin")
  endemic_districts_half <- c("kachin","kayin","bago","magway","mandalay","sagaing","taninthayi","mon","yangon","ayeyarwaddy")
  endemic_districts_all <- c("kachin","kayin","bago","mandalay","taninthayi","mon","yangon","ayeyarwaddy")
}

endemic_ifAny <- rep("non endemic",length(districts))
endemic_half <- rep("non endemic",length(districts))
endemic_all <- rep("non endemic",length(districts))

for(i in 1:length(endemic_districts_ifAny)){
  row <- which(districts == endemic_districts_ifAny[i])
  endemic_ifAny[row] <- "endemic"
}
for(i in 1:length(endemic_districts_half)){
  row <- which(districts == endemic_districts_half[i])
  endemic_half[row] <- "endemic"
}
for(i in 1:length(endemic_districts_all)){
  row <- which(districts == endemic_districts_all[i])
  endemic_all[row] <- "endemic"
}
LFendemicCovFrame$anyEndemic <- endemic_ifAny
LFendemicCovFrame$halfEndemic <- endemic_half
LFendemicCovFrame$allEndemic <- endemic_all


#Endemic Districts by Percent Sub-Regions Endemic
endemic_percent <- c()
for(i in 1:length(districts)){
  endemic_count <- length(which(lf_frame$`Province/State` == districts[i] & lf_frame$Endemicity == "endemic"))
  endemic_total <- length(which(lf_frame$`Province/State` == districts[i]))
  endemic_percent[i] <- (endemic_count/endemic_total)*100
}
LFendemicCovFrame$percentEndemic <- endemic_percent

endemic_percentBin <- c()
endemic_percentBinOrder <- c()
for(i in 1:length(districts)){
  if(LFendemicCovFrame$percentEndemic[i] == 0){
    endemic_percentBin[i] <- "0%"
    endemic_percentBinOrder[i] <- 1
  }
  if(LFendemicCovFrame$percentEndemic[i] > 0 && LFendemicCovFrame$percentEndemic[i] < 50){
    endemic_percentBin[i] <- "1%-50%"
    endemic_percentBinOrder[i] <- 2
  }
  if(LFendemicCovFrame$percentEndemic[i] > 50 && LFendemicCovFrame$percentEndemic[i] < 100){
    endemic_percentBin[i] <- "51%-99%"
    endemic_percentBinOrder[i] <- 3
  }
  if(LFendemicCovFrame$percentEndemic[i] == 100){
    endemic_percentBin[i] <- "100%"
    endemic_percentBinOrder[i] <- 4
  }
}
LFendemicCovFrame$percentBin <- endemic_percentBin
LFendemicCovFrame$percentBinOrder <- endemic_percentBinOrder

#HALF ENDEMIC FRAME
endemicTitle <- unique(LFendemicCovFrame$halfEndemic)
mean_halfEndemic <- c()
sd_halfEndemic <- c()
for(i in 1:length(endemicTitle)){
  mean_halfEndemic[i] <- mean(LFendemicCovFrame$cov_difference[LFendemicCovFrame$halfEndemic == endemicTitle[i]])
  sd_halfEndemic[i] <- sd(LFendemicCovFrame$cov_difference[LFendemicCovFrame$halfEndemic == endemicTitle[i]])
}
halfEndemic_frame <- data.frame(endemicTitle,mean_halfEndemic,sd_halfEndemic)


#ANY ENDEMIC FRAME
endemicTitle <- unique(LFendemicCovFrame$anyEndemic)
mean_anyEndemic <- c()
sd_anyEndemic <- c()
for(i in 1:length(endemicTitle)){
  mean_anyEndemic[i] <- mean(abs(LFendemicCovFrame$cov_difference[LFendemicCovFrame$anyEndemic == endemicTitle[i]]))
  sd_anyEndemic[i] <- sd(abs(LFendemicCovFrame$cov_difference[LFendemicCovFrame$anyEndemic == endemicTitle[i]]))
}
anyEndemic_frame <- data.frame(endemicTitle,mean_anyEndemic,sd_anyEndemic)


#ALL ENDEMIC FRAME
endemicTitle <- unique(LFendemicCovFrame$allEndemic)
mean_allEndemic <- c()
sd_allEndemic <- c()
for(i in 1:length(endemicTitle)){
  mean_allEndemic[i] <- mean(LFendemicCovFrame$cov_difference[LFendemicCovFrame$allEndemic == endemicTitle[i]])
  sd_allEndemic[i] <- sd(LFendemicCovFrame$cov_difference[LFendemicCovFrame$allEndemic == endemicTitle[i]])
}
allEndemic_frame <- data.frame(endemicTitle,mean_allEndemic,sd_allEndemic)


#PERCENT BIN ENDEMIC FRAME
percentEndemicBins <- unique(LFendemicCovFrame$percentBin)
mean_percentEndemic <- c()
sd_percentEndemic <- c()
for(i in 1:length(percentEndemicBins)){
  mean_percentEndemic[i] <- mean(LFendemicCovFrame$cov_difference[LFendemicCovFrame$percentBin == percentEndemicBins[i]])
  sd_percentEndemic[i] <- sd(LFendemicCovFrame$cov_difference[LFendemicCovFrame$percentBin == percentEndemicBins[i]])
}
percentEndemic_frame <- data.frame(percentEndemicBins,mean_percentEndemic,sd_percentEndemic)
percentEndemic_frame$percentEndemicBins <- factor(percentEndemic_frame$percentEndemicBins,levels = c("0%", "1%-50%", "51%-99%", "100%"))

#GRAPHING
halfEndemic_frame$endemicTitle <- c("50-100% (endemic)","0-49% (non endemic)")
p <- ggplot(halfEndemic_frame, aes(y=mean_halfEndemic, x=endemicTitle, ymin=mean_halfEndemic-(sd_halfEndemic), ymax=mean_halfEndemic+(sd_halfEndemic))) +
  geom_bar(stat="identity", fill = "cyan3") +
  labs(title = "Coverage difference by LF endemicity in Myanmar ", y = "Coverage Difference (WHO - DHS)", x = "LF endemicity") +
  expand_limits(y=c(0,100)) + scale_y_continuous(breaks=seq(0, 100, 10)) +
  theme(text=element_text(family="Times New Roman")) +
  theme(axis.text.x =element_text(size=25), axis.text.y =element_text(size=28), axis.title=element_text(size=31,face="bold"), plot.title = element_text(size=28))
print(p)

anyEndemic_frame$endemicTitle <- c("1-100% (endemic)","0% (non endemic)")
p <- ggplot(anyEndemic_frame, aes(y=mean_anyEndemic, x=endemicTitle, ymin=mean_anyEndemic-(sd_anyEndemic), ymax=mean_anyEndemic+(sd_anyEndemic))) +
  geom_bar(stat="identity", fill = "cyan3") +
  labs(title = "Coverage difference by LF endemicity in the Myanmar", y = "Coverage Difference (WHO - DHS)", x = "LF endemicity") +
  expand_limits(y=c(0,100)) + scale_y_continuous(breaks=seq(0, 100, 10)) +
  theme(text=element_text(family="Times New Roman")) +
  theme(axis.text.x =element_text(size=25), axis.text.y =element_text(size=28), axis.title=element_text(size=28,face="bold"), plot.title = element_text(size=28))
print(p)
