############ PROJECT DESCRIPTION ##################
# Project: Deworming in pre-school children Data Validation (Suppl. 2 of 2)

# Coded by Ribhav Gupta (Stanford University)
# Email: ribhav.gupta97@gmail.com
# Last updated: 10/03/19 

#Purpose of File: Generates excel for use in Stata for weighted estimates using DHS data

# Files Required:
#   1. Files from WHO on deworming program
#   2. Files from DHS on individual data

# **Note: Directory should be updated based on where files are saved.**

#File Outputs:
# 1. 
# 2. 

############ ANALYSIS ##################
setwd("/Users/rgupta97/Documents/Lab_Work")
DHS_data_raw <- read_excel("TEST_Indonesia.xlsx")
DHS_data_raw <- na.omit(DHS_data_raw)
DHS_data_raw <- DHS_data_raw[DHS_data_raw$cycles_included != 0,]

cluster <- c()
weight <- c()
strata <- c()
region <- c()
deworm_all <- c()
region_dhs <- c()

cluster_male <- c()
weight_male <- c()
strata_male <- c()
region_male <- c()
deworm_male <- c()
region_dhs_male <- c()

cluster_female <- c()
weight_female <- c()
strata_female <- c()
region_female <- c()
deworm_female <- c()
region_dhs_female <- c()

num_presac <- 0
num_mothers <- 0
for(r in 1:nrow(DHS_data_raw)){
  num_mothers <- num_mothers + 1
  if((DHS_data_raw$med_count_all[r] + DHS_data_raw$not_med_all[r]) > 0){
    for(s in 1:(DHS_data_raw$med_count_all[r] + DHS_data_raw$not_med_all[r])){
      num_presac <- num_presac + 1
      cluster[length(cluster) + 1] <- DHS_data_raw$cluster[r]
      weight[length(weight) + 1] <- DHS_data_raw$weight[r]
      strata[length(strata) + 1] <- DHS_data_raw$strata[r]
      region[length(region) + 1] <- DHS_data_raw$region[r]
      region_dhs[length(region_dhs) + 1] <- DHS_data_raw$region_dhs[r]
      if(s <= DHS_data_raw$med_count_all[r]){
        deworm_all[length(deworm_all) + 1] <- 1
      }
      if(s > DHS_data_raw$med_count_all[r]){
        deworm_all[length(deworm_all) + 1] <- 0
      }
    }
  }
}

for(r in 1:nrow(DHS_data_raw)){
  if((DHS_data_raw$med_count_male[r] + DHS_data_raw$not_med_male[r]) > 0){
    for(s in 1:(DHS_data_raw$med_count_male[r] + DHS_data_raw$not_med_male[r])){
      cluster_male[length(cluster_male) + 1] <- DHS_data_raw$cluster[r]
      weight_male[length(weight_male) + 1] <- DHS_data_raw$weight[r]
      strata_male[length(strata_male) + 1] <- DHS_data_raw$strata[r]
      region_male[length(region_male) + 1] <- DHS_data_raw$region[r]
      region_dhs_male[length(region_dhs_male) + 1] <- DHS_data_raw$region_dhs[r]
      if(s <= DHS_data_raw$med_count_male[r]){
        deworm_male[length(deworm_male) + 1] <- 1
      }
      if(s > DHS_data_raw$med_count_male[r]){
        deworm_male[length(deworm_male) + 1] <- 0
      }
    }
  }
}

for(r in 1:nrow(DHS_data_raw)){
  if((DHS_data_raw$med_count_female[r] + DHS_data_raw$not_med_female[r]) > 0){
    for(s in 1:(DHS_data_raw$med_count_female[r] + DHS_data_raw$not_med_female[r])){
      cluster_female[length(cluster_female) + 1] <- DHS_data_raw$cluster[r]
      weight_female[length(weight_female) + 1] <- DHS_data_raw$weight[r]
      strata_female[length(strata_female) + 1] <- DHS_data_raw$strata[r]
      region_female[length(region_female) + 1] <- DHS_data_raw$region[r]
      region_dhs_female[length(region_dhs_female) + 1] <- DHS_data_raw$region_dhs[r]
      if(s <= DHS_data_raw$med_count_female[r]){
        deworm_female[length(deworm_female) + 1] <- 1
      }
      if(s > DHS_data_raw$med_count_female[r]){
        deworm_female[length(deworm_female) + 1] <- 0
      }
    }
  }
}



final_frame_all <- data.frame(cluster,weight,strata,region,region_dhs,deworm_all)
final_frame_male <- data.frame(cluster_male,weight_male,strata_male,region_male,region_dhs_male,deworm_male)
final_frame_female <- data.frame(cluster_female,weight_female,strata_female,region_female,region_dhs_female,deworm_female)

WriteXLS(c("final_frame_all","final_frame_male","final_frame_female"),ExcelFileName = "Indonesia_SE_Stata.xlsx", SheetNames = c("All pSAC","boy pSAC","girl pSAC"))
